const qs=[
{t:'1. I _____ originally from Jakarta, and I work _____ a graphic designer.',a:['','']},
{t:'2. Pilih jawaban',c:['A','B','C'],k:1},
{t:'3. Lantai 3?',a:['']},
{t:'4. Cara membaca $1.55?',a:['']},
{t:'5. 08:45 British?',a:['']},
{t:'6. 06:15 American?',a:['']},
{t:'7. She _____ English every day.',c:['study','studies'],k:1},
{t:'8. Negatif: I drink coffee every morning.',a:['']},
{t:'9. Tanya: They work on Saturday.',a:['']},
{t:'10. Translate: Pertama, saya bangun tidur. Lalu, saya mandi.',a:['']}
];
let i=0;const ans={};
function render(){let q=qs[i],h='<h3>'+q.t+'</h3>';if(q.c){q.c.forEach((x,n)=>h+=`<label><input type=radio name=o ${ans[i]==n?'checked':''} onchange="ans[${i}]=${n}">${x}</label><br>`)}else{q.a.forEach((_,n)=>h+=`<input value="${ans[i+'-'+n]||''}" oninput="ans['${i}-'+${n}]=this.value"><br>`)};document.getElementById('q').innerHTML=h;}
function prev(){if(i>0)i--;render()}
function next(){if(i<qs.length-1)i++;render()}
function finish(){let s=0;if(ans[1]===1)s+=10;if(ans[6]===1)s+=10;alert("Skor otomatis pilihan ganda: "+s+"/20\nSoal isian perlu diperiksa manual.");}
render();